# Main Streamlit App
print('ApplyMate Sports Pro Edition Running...')